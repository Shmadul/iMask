#!/bin/bash
echo "if [ \"$1\" = \"\" ];
then
echo \"autorandomize -s {Will Randomize Host every x Time in Seconds}\"
exit 0
fi
if [ \"$1\" != \"\" ];
then
plutil -replace 'StartInterval' -integer $1 '/Library/LaunchDaemons/com.shmadul.iMask.plist'
echo \"HostName will be randomized every:\" $1 \"Second(s)\"
fi
"